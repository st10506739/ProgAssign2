package WildLifeRescue;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class RescueTest {

    private RescueManager manager;
    private InjuredAnimalRescue injured;
    private OrphanedAnimalRescue orphan;
    private EndangeredSpeciesRescue endangered;

    @BeforeEach
    void setUp() {
        manager = new RescueManager();
        // 5 x 1000 + 10000 + 5000 (surgery) = 20000
        injured = new InjuredAnimalRescue("WR101", "Zola", "African Elephant", "Kruger",
                "Dlamini", 5, 1000, "Snare wound", 10000, true);
        // 4 x 500 + 7000 + 2500 (foster) = 11500
        orphan = new OrphanedAnimalRescue("WR102", "Thabo", "White Rhino", "Hluhluwe",
                "Nkosi", 4, 500, 8, 7000, true);
        // 3 x 800 + 6000 + 8000 (specialist) = 16400
        endangered = new EndangeredSpeciesRescue("WR103", "Kito", "Pangolin", "Limpopo",
                "Naidoo", 3, 800, "Critically Endangered", 6000, true);
    }

    // ---------- Cost calculations ----------
    @Test
    void injuredCostIncludesVetAndSurgery() {
        assertEquals(20000.00, injured.calculateTotalCost(), 0.001);
    }

    @Test
    void injuredCostWithoutSurgery() {
        InjuredAnimalRescue rc = new InjuredAnimalRescue("WR201", "A", "Lion", "Kruger",
                "Dlamini", 2, 500, "Cut", 3000, false);
        assertEquals(4000.00, rc.calculateTotalCost(), 0.001);
    }

    @Test
    void orphanCostIncludesFeedingAndFoster() {
        assertEquals(11500.00, orphan.calculateTotalCost(), 0.001);
    }

    @Test
    void orphanCostWithoutFoster() {
        OrphanedAnimalRescue rc = new OrphanedAnimalRescue("WR202", "B", "Zebra", "Kruger",
                "Nkosi", 2, 500, 10, 1000, false);
        assertEquals(2000.00, rc.calculateTotalCost(), 0.001);
    }

    @Test
    void endangeredCostIncludesSecurityAndSpecialist() {
        assertEquals(16400.00, endangered.calculateTotalCost(), 0.001);
    }

    // ---------- Priority calculations ----------
    @Test
    void injuredWithSurgeryIsCritical() {
        assertEquals("Critical", injured.determinePriority());
    }

    @Test
    void injuredHighVetCostNoSurgeryIsHigh() {
        InjuredAnimalRescue rc = new InjuredAnimalRescue("WR203", "C", "Lion", "Kruger",
                "Dlamini", 2, 500, "Fracture", 12000, false);
        assertEquals("High", rc.determinePriority());
    }

    @Test
    void orphanEightMonthsIsHigh() {
        assertEquals("High", orphan.determinePriority());
    }

    @Test
    void endangeredCriticallyEndangeredIsCritical() {
        assertEquals("Critical", endangered.determinePriority());
    }

    @Test
    void endangeredVulnerableIsMedium() {
        EndangeredSpeciesRescue rc = new EndangeredSpeciesRescue("WR204", "D", "Cheetah",
                "Kruger", "Naidoo", 2, 500, "Vulnerable", 2000, false);
        assertEquals("Medium", rc.determinePriority());
    }

    // ---------- Status updates ----------
    @Test
    void newCaseIsReported() {
        assertEquals(RescueStatus.REPORTED, injured.getStatus());
    }

    @Test
    void startRescueSetsInProgress() {
        assertTrue(injured.startRescue());
        assertEquals(RescueStatus.RESCUE_IN_PROGRESS, injured.getStatus());
    }

    @Test
    void completeRescueSetsCompleted() {
        injured.startRescue();
        assertTrue(injured.completeRescue());
        assertEquals(RescueStatus.RESCUE_COMPLETED, injured.getStatus());
    }

    @Test
    void cannotStartCompletedRescue() {
        injured.completeRescue();
        assertFalse(injured.startRescue());
        assertEquals(RescueStatus.RESCUE_COMPLETED, injured.getStatus());
    }

    // ---------- Searching ----------
    @Test
    void searchFindsExistingCase() {
        manager.addCase(injured);
        manager.addCase(orphan);
        assertSame(orphan, manager.findById("WR102"));
    }

    @Test
    void searchReturnsNullForMissingCase() {
        manager.addCase(injured);
        assertNull(manager.findById("WR999"));
    }

    // ---------- Duplicate IDs ----------
    @Test
    void duplicateIdIsRejected() {
        assertTrue(manager.addCase(injured));
        InjuredAnimalRescue duplicate = new InjuredAnimalRescue("WR101", "Other", "Lion",
                "Kruger", "Dlamini", 1, 100, "Cut", 500, false);
        assertFalse(manager.addCase(duplicate));
        assertEquals(1, manager.getCaseCount());
    }

    // ---------- Validation / report ----------
    @Test
    void blankSpeciesThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                new InjuredAnimalRescue("WR300", "E", " ", "Kruger", "Dlamini",
                        1, 100, "Cut", 500, false));
    }

    @Test
    void reportTotalsAreCorrect() {
        manager.addCase(injured);
        manager.addCase(orphan);
        assertEquals(2, manager.getCaseCount());
        assertEquals(31500.00, manager.getTotalRescueCost(), 0.001);
    }
}